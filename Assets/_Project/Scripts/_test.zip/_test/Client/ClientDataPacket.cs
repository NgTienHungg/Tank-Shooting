﻿using System;
using System.IO;
using UnityEngine;
using System.Runtime.Serialization;
using System.Runtime.Serialization.Formatters.Binary;

[Serializable]
public class ClientDataPacket
{
     // Đặt các thuộc tính bạn muốn lưu trữ ở đây
     // Ví dụ: public PlayerPosition position;
     //        public PlayerConfig config;

     public ClientDataPacket()
     {
          // Khởi tạo các thuộc tính tại đây nếu cần thiết
     }

     public static byte[] Serialize(ClientDataPacket packet)
     {
          using (MemoryStream memoryStream = new MemoryStream())
          {
               IFormatter formatter = new BinaryFormatter();
               formatter.Serialize(memoryStream, packet);
               return memoryStream.ToArray();
          }
     }

     public static ClientDataPacket Deserialize(byte[] data)
     {
          using (MemoryStream memoryStream = new MemoryStream(data))
          {
               IFormatter formatter = new BinaryFormatter();
               try
               {
                    return (ClientDataPacket)formatter.Deserialize(memoryStream);
               }
               catch (Exception ex)
               {
                    Debug.LogError("Deserialization Error: " + ex.Message);
                    return null;
               }
          }
     }
}