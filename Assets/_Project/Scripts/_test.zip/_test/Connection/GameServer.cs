﻿using System;
using System.Net;
using UnityEngine;
using System.Net.Sockets;
using Sirenix.OdinInspector;
using System.Collections.Generic;

public class GameServer : Singleton<GameServer>
{
     [ShowInInspector, ReadOnly] public static int PORT = 9000;
     [ShowInInspector, ReadOnly] public static int MAX_PLAYERS = 4;

     private UdpClient server;
     private Dictionary<string, IPEndPoint> clientIPs;

     private void Start()
     {
          server = new UdpClient(PORT);
          clientIPs = new Dictionary<string, IPEndPoint>();
     }

     private void Update()
     {
          try
          {
               IPEndPoint clientEndPoint = new IPEndPoint(IPAddress.Any, 0);
               byte[] byteData = server.Receive(ref clientEndPoint);

               HandleNewClient(clientEndPoint);
               HandleReceivedData(byteData, clientEndPoint);
          }
          catch (Exception e)
          {
               Debug.LogError("Server error: " + e.Message);
          }
     }

     private void HandleNewClient(IPEndPoint clientEndPoint)
     {
          string clientIP = clientEndPoint.Address.ToString();

          if (clientIPs.ContainsKey(clientIP))
          {
               if (clientIPs.Count >= MAX_PLAYERS)
               {
                    Debug.LogWarning("Room is full!");
                    return;
               }

               Debug.Log($"New player join room: {clientIP}");
               clientIPs.Add(clientIP, clientEndPoint);

               // create new player in room
               Debug.Log("<color=cyan> Generate new player </color>");

               //UnityMainThreadDispatcher.Instance().Enqueue(() =>
               //{

               //});
          }
     }

     private void HandleReceivedData(byte[] byteData, IPEndPoint clientEndPoint)
     {
          // Process received data (you can add your logic here)
          // Example: Deserialize the data
          //ClientDataPacket data = ClientDataPacket.Deserialize(byteData);

          //if (data == null)
          //{
          //     Debug.LogWarning("Data is null");
          //     return;
          //}
     }

     private void OnDestroy()
     {
          server.Close();
     }
}