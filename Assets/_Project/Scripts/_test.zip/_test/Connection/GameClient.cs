using System.Net;
using System.Text;
using System.Net.Sockets;
using Sirenix.OdinInspector;

public class GameClient : Singleton<GameClient>
{
     [ShowInInspector, ReadOnly] public static string SERVER_IP = "192.168.2.7";
     [ShowInInspector, ReadOnly] public static int SERVER_PORT = 9000;

     private static UdpClient client;

     private void Start()
     {
          client = new UdpClient();
     }

     private void OnDestroy()
     {
          client.Close();
     }

     public static void SendMessageUDP(string message)
     {
          IPEndPoint serverEndPoint = new IPEndPoint(IPAddress.Parse(SERVER_IP), SERVER_PORT);
          byte[] byteMessage = Encoding.ASCII.GetBytes(message);
          client.Send(byteMessage, byteMessage.Length, serverEndPoint);
     }

     public static string ReceiveMessageUDP()
     {
          IPEndPoint responseEndPoint = new IPEndPoint(IPAddress.Any, 0);
          byte[] response = client.Receive(ref responseEndPoint);
          return Encoding.ASCII.GetString(response);
     }
}