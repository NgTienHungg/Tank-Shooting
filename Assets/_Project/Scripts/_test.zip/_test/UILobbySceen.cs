using TMPro;
using UnityEngine;

public class UILobbySceen : MonoBehaviour
{
     public TMP_InputField inputField;

     public void OnClickSubmitButton()
     {
          string message = inputField.text;
          Debug.Log($"Send message: {message}");
          GameClient.SendMessageUDP(message);
     }
}